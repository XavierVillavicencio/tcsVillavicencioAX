from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "Informe_Trabajo_Realizado_PruebaProdu.docx"


COLORS = {
    "heading": RGBColor(0x2E, 0x74, 0xB5),
    "heading_dark": RGBColor(0x1F, 0x4D, 0x78),
    "body": RGBColor(0x1F, 0x29, 0x37),
    "muted": RGBColor(0x66, 0x72, 0x80),
    "table_header": "F2F4F7",
    "callout": "F4F6F9",
    "border": "B8C2CC",
}


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)

    for margin_name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin_name}"))
        if node is None:
            node = OxmlElement(f"w:{margin_name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table, color=COLORS["border"], size="6"):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)

    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        node = borders.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            borders.append(node)
        node.set(qn("w:val"), "single")
        node.set(qn("w:sz"), size)
        node.set(qn("w:space"), "0")
        node.set(qn("w:color"), color)


def set_table_widths(table, widths):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT

    tbl = table._tbl
    tbl_pr = tbl.tblPr

    tbl_w = tbl_pr.first_child_found_in("w:tblW")
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")

    grid = tbl.tblGrid
    if grid is None:
        grid = OxmlElement("w:tblGrid")
        tbl.insert(0, grid)
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for index, width in enumerate(widths):
            cell = row.cells[index]
            cell.width = Inches(width / 1440)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.first_child_found_in("w:tcW")
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_margins(cell)


def format_table(table, widths, header=True):
    set_table_widths(table, widths)
    set_table_borders(table)
    for row_index, row in enumerate(table.rows):
        for cell in row.cells:
            if row_index == 0 and header:
                set_cell_shading(cell, COLORS["table_header"])
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(3)
                for run in paragraph.runs:
                    run.font.name = "Calibri"
                    run.font.size = Pt(9.5)
                    run.font.color.rgb = COLORS["body"]
                    if row_index == 0 and header:
                        run.bold = True


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    for index, header in enumerate(headers):
        table.rows[0].cells[index].text = header

    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].text = value

    format_table(table, widths)
    doc.add_paragraph()
    return table


def add_callout(doc, title, text):
    table = doc.add_table(rows=1, cols=1)
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, COLORS["callout"])
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run(title)
    run.bold = True
    run.font.color.rgb = COLORS["heading_dark"]
    run.font.size = Pt(10.5)
    p2 = cell.add_paragraph(text)
    p2.paragraph_format.space_after = Pt(0)
    for run in p2.runs:
        run.font.size = Pt(10)
    format_table(table, [9360], header=False)
    doc.add_paragraph()


def add_bullet(doc, text):
    paragraph = doc.add_paragraph(style="List Bullet")
    paragraph.paragraph_format.space_after = Pt(4)
    paragraph.paragraph_format.line_spacing = 1.167
    paragraph.add_run(text)
    return paragraph


def add_numbered(doc, text):
    paragraph = doc.add_paragraph(style="List Number")
    paragraph.paragraph_format.space_after = Pt(4)
    paragraph.paragraph_format.line_spacing = 1.167
    paragraph.add_run(text)
    return paragraph


def setup_document():
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.font.color.rgb = COLORS["body"]
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for style_name, size, color, before, after in (
        ("Heading 1", 16, COLORS["heading"], 16, 8),
        ("Heading 2", 13, COLORS["heading"], 12, 6),
        ("Heading 3", 12, COLORS["heading_dark"], 8, 4),
    ):
        style = styles[style_name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)

    header = section.header.paragraphs[0]
    header.text = "Informe tecnico - PruebaProdu"
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    header.runs[0].font.size = Pt(9)
    header.runs[0].font.color.rgb = COLORS["muted"]

    footer = section.footer.paragraphs[0]
    footer.text = "Documento generado para revision del caso practico"
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.runs[0].font.size = Pt(9)
    footer.runs[0].font.color.rgb = COLORS["muted"]

    return doc


def build_report():
    doc = setup_document()

    title = doc.add_paragraph()
    title.paragraph_format.space_after = Pt(3)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run = title.add_run("Informe del trabajo realizado")
    run.font.name = "Calibri"
    run.font.size = Pt(24)
    run.font.bold = True
    run.font.color.rgb = COLORS["heading_dark"]

    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(14)
    subtitle.add_run("Proyecto PruebaProdu - Caso practico Angular, .NET y Redis").italic = True

    meta_rows = [
        ("Fecha", "06 de junio de 2026"),
        ("Directorio de trabajo", r"C:\laragon\www\PruebaProdu"),
        ("Alcance", "Frontend Angular 21, backend .NET 8, Redis y arquitectura hexagonal"),
        ("Estado", "Compilacion y pruebas funcionales ejecutadas correctamente"),
    ]
    add_table(doc, ["Campo", "Detalle"], meta_rows, [2300, 7060])

    add_callout(
        doc,
        "Resumen ejecutivo",
        "Se preparo el entorno backend, se implemento una API .NET para transacciones con Redis, "
        "se conecto el frontend Angular mediante HTTP y se refactorizo la solucion hacia un modelo "
        "de arquitectura hexagonal sin cambiar la logica funcional existente.",
    )

    doc.add_heading("1. Trabajo realizado", level=1)
    for item in [
        "Instalacion del SDK .NET 8.0.421 para crear, compilar y ejecutar el backend.",
        "Levantamiento de Redis desde Laragon y verificacion de disponibilidad mediante redis-cli ping.",
        "Creacion del proyecto backend ASP.NET Core Web API en la carpeta back.",
        "Implementacion de endpoints CRUD para transacciones usando Redis como almacenamiento en memoria.",
        "Configuracion de CORS y proxy para permitir integracion con Angular en localhost:4200.",
        "Incorporacion de modo oscuro en el frontend con persistencia en localStorage.",
        "Sustitucion del texto del boton de tema por iconos de sol/luna usando @lucide/angular.",
        "Refactor del backend a arquitectura hexagonal manteniendo los contratos HTTP.",
    ]:
        add_bullet(doc, item)

    doc.add_heading("2. Arquitectura aplicada", level=1)
    doc.add_paragraph(
        "La solucion quedo organizada bajo el enfoque de arquitectura hexagonal, tambien conocido como "
        "ports and adapters. La regla principal aplicada fue mantener el dominio y los casos de uso libres "
        "de dependencias de infraestructura, mientras que Redis y HTTP funcionan como adaptadores externos."
    )

    architecture_rows = [
        ("Domain", "Modelo de negocio", "Transaction, TransactionType"),
        ("Application", "Casos de uso y puertos", "Create, list, get, update, delete; ITransactionRepository"),
        ("Infrastructure", "Adaptadores externos", "RedisTransactionRepository con StackExchange.Redis"),
        ("Api", "Adaptador de entrada", "Minimal APIs agrupadas en /api/transactions"),
        ("Composition root", "Cableado de dependencias", "Program.cs y modulos DependencyInjection"),
    ]
    add_table(doc, ["Capa", "Responsabilidad", "Elementos principales"], architecture_rows, [1900, 2900, 4560])

    doc.add_heading("3. Patrones de diseno identificados", level=1)
    pattern_rows = [
        ("Ports and Adapters", "Aisla el nucleo de negocio de HTTP y Redis."),
        ("Repository", "ITransactionRepository define el puerto de persistencia; Redis es su implementacion."),
        ("Use Case / Application Service", "Cada operacion del CRUD se expresa como un caso de uso independiente."),
        ("Dependency Injection", "Las dependencias se resuelven por contenedor, no por instanciacion directa."),
        ("DTO / Command", "Los contratos HTTP se separan de los comandos de aplicacion."),
        ("Result Pattern", "UseCaseResult<T> comunica exito, error de validacion o recurso no encontrado."),
        ("Adapter", "La API HTTP y Redis traducen solicitudes externas hacia el nucleo de aplicacion."),
    ]
    add_table(doc, ["Patron", "Uso en el proyecto"], pattern_rows, [2600, 6760])

    doc.add_heading("4. Funcionalidad implementada", level=1)
    doc.add_heading("Backend .NET", level=2)
    for item in [
        "GET /api/transactions para listar transacciones.",
        "GET /api/transactions/{id} para consultar una transaccion por identificador.",
        "POST /api/transactions para crear una transaccion.",
        "PUT /api/transactions/{id} para actualizar una transaccion existente.",
        "DELETE /api/transactions/{id} para eliminar una transaccion.",
        "Validaciones de descripcion, monto positivo y tipo de transaccion.",
        "Generacion automatica del identificador de transaccion mediante Guid.",
    ]:
        add_bullet(doc, item)

    doc.add_heading("Frontend Angular", level=2)
    for item in [
        "Pantalla Resumen con listado, totales y diferenciacion visual entre credito y debito.",
        "Pantalla Transaccion con formulario reactivo, validaciones y boton Enviar condicionado por validez.",
        "Navegacion entre Resumen y Transaccion con menu activo.",
        "Modo oscuro global con boton de icono y persistencia de preferencia.",
        "Consumo de API mediante repositorio HTTP inyectado por puerto de aplicacion.",
    ]:
        add_bullet(doc, item)

    doc.add_heading("5. Verificaciones ejecutadas", level=1)
    verification_rows = [
        ("Backend", "dotnet build", "Correcto, 0 errores y 0 advertencias."),
        ("Frontend", "npm run build", "Correcto, bundle generado correctamente."),
        ("Frontend", "npm test -- --run", "Correcto, 3 archivos de prueba y 5 tests pasaron."),
        ("Redis", "redis-cli ping", "Correcto, respuesta PONG."),
        ("API CRUD", "POST, GET, PUT, DELETE", "Correcto, flujo probado contra Redis despues del refactor."),
    ]
    add_table(doc, ["Area", "Comando / prueba", "Resultado"], verification_rows, [1800, 2600, 4960])

    doc.add_heading("6. Cumplimiento del PDF inicial", level=1)
    compliance_rows = [
        ("Angular 21", "Cumple", "El frontend usa Angular 21 segun package.json."),
        ("Tailwind", "Cumple", "Los estilos se implementan con Tailwind CSS."),
        ("No PrimeNG / Material", "Cumple", "No se incorporaron esas librerias."),
        ("Backend .NET", "Cumple", "Se creo backend ASP.NET Core sobre .NET 8."),
        ("CRUD de transacciones", "Cumple", "Endpoints completos para crear, listar, consultar, actualizar y eliminar."),
        ("Redis en memoria", "Cumple", "StackExchange.Redis conectado a Redis local de Laragon."),
        ("Credito verde", "Cumple", "El frontend muestra creditos con tratamiento visual verde."),
        ("Debito rojo y signo menos", "Cumple", "El frontend muestra debitos en rojo y prefijo negativo."),
        ("Nueva Transaccion redirecciona", "Cumple", "El boton navega al formulario de transaccion."),
        ("Campos obligatorios", "Cumple", "Formulario reactivo con validadores requeridos."),
        ("Enviar condicionado", "Cumple", "El boton Enviar se deshabilita si el formulario es invalido."),
        ("Limpiar formulario", "Cumple", "El boton Limpiar restablece el formulario actual."),
        ("Monto numerico", "Cumple", "Input numerico y validacion de monto mayor a cero."),
        ("Tipo debito/credito", "Cumple", "Radio buttons para Credit y Debit."),
        ("ID automatico", "Cumple", "El backend genera el identificador con Guid."),
        ("Azure DevOps / notificacion", "Pendiente externo", "Depende del proceso de entrega y credenciales del usuario."),
    ]
    add_table(doc, ["Requisito", "Estado", "Evidencia"], compliance_rows, [2600, 1700, 5060])

    doc.add_heading("7. Conclusiones", level=1)
    for item in [
        "La solucion cumple con los requisitos funcionales y tecnologicos principales del caso practico.",
        "El backend quedo desacoplado de Redis y HTTP mediante puertos, casos de uso y adaptadores.",
        "El frontend mantiene una estructura compatible con arquitectura hexagonal al separar dominio, aplicacion, infraestructura y presentacion.",
        "Las pruebas de compilacion y flujo CRUD confirman que el refactor no rompio el comportamiento existente.",
    ]:
        add_numbered(doc, item)

    doc.add_heading("8. Comandos utiles", level=1)
    command_rows = [
        ("Levantar backend", r"cd C:\laragon\www\PruebaProdu\back && dotnet run"),
        ("Levantar frontend", r"cd C:\laragon\www\PruebaProdu\front && npm start"),
        ("Compilar backend", r"dotnet build"),
        ("Compilar frontend", r"npm run build"),
        ("Ejecutar tests frontend", r"npm test -- --run"),
        ("Verificar Redis", r"redis-cli ping"),
    ]
    add_table(doc, ["Accion", "Comando"], command_rows, [2400, 6960])

    doc.core_properties.title = "Informe del trabajo realizado - PruebaProdu"
    doc.core_properties.subject = "Caso practico Angular .NET Redis"
    doc.core_properties.author = "Codex"
    doc.core_properties.keywords = "Angular, .NET, Redis, Arquitectura Hexagonal, Caso Practico"
    doc.core_properties.created = datetime.now()

    doc.save(OUTPUT)


if __name__ == "__main__":
    build_report()
    print(OUTPUT)

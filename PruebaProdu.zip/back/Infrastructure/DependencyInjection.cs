/*
 * Proposito: registra servicios de infraestructura, incluida la conexion Redis y el repositorio concreto.
 * Entradas: IServiceCollection y IConfiguration con la cadena de conexion Redis.
 * Salidas: servicios de infraestructura disponibles para la API mediante inyeccion de dependencias.
 * Dependencias: usa StackExchange.Redis y el puerto ITransactionRepository definido en Application.
 * Calidad: respeta inversion de dependencias al conectar infraestructura mediante interfaces.
 */
using Back.Application.Transactions.Ports;
using Back.Infrastructure.Persistence.Redis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;

namespace Back.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var redisConnection = configuration.GetConnectionString("Redis") ?? "localhost:6379";

        services.AddSingleton<IConnectionMultiplexer>(_ => ConnectionMultiplexer.Connect(redisConnection));
        services.AddScoped<ITransactionRepository, RedisTransactionRepository>();

        return services;
    }
}

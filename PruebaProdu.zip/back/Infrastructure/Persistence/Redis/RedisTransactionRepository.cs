/*
 * Proposito: implementa la persistencia de transacciones en Redis.
 * Entradas: entidades Transaction e identificadores usados por los casos de uso.
 * Salidas: transacciones recuperadas, confirmaciones de guardado/eliminacion y valores null si no existen.
 * Dependencias: implementa ITransactionRepository y usa StackExchange.Redis para acceso a datos.
 * Calidad: encapsula detalles de Redis, serializa de forma consistente y mantiene la capa Application desacoplada.
 */
using System.Text.Json;
using System.Text.Json.Serialization;
using Back.Application.Transactions.Ports;
using Back.Domain.Transactions;
using StackExchange.Redis;

namespace Back.Infrastructure.Persistence.Redis;

public sealed class RedisTransactionRepository : ITransactionRepository
{
    private const string IndexKey = "transactions:index";
    private const string KeyPrefix = "transactions:";
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly IDatabase database;

    /// <summary>
    /// Inicializa el repositorio obteniendo la base de datos Redis desde la conexion compartida.
    /// </summary>
    public RedisTransactionRepository(IConnectionMultiplexer connection)
    {
        database = connection.GetDatabase();
    }

    /// <summary>
    /// Obtiene todas las transacciones registradas en Redis y las devuelve ordenadas por fecha descendente.
    /// </summary>
    public async Task<IReadOnlyCollection<Transaction>> GetAllAsync()
    {
        var ids = await database.SetMembersAsync(IndexKey);
        var tasks = ids.Select(id => GetByIdAsync(id!));
        var transactions = await Task.WhenAll(tasks);

        return transactions
            .OfType<Transaction>()
            .OrderByDescending(transaction => transaction.Date)
            .ToArray();
    }

    /// <summary>
    /// Busca una transaccion por su identificador y la deserializa desde Redis si existe.
    /// </summary>
    public async Task<Transaction?> GetByIdAsync(string id)
    {
        var value = await database.StringGetAsync(GetKey(id));
        return value.IsNullOrEmpty
            ? null
            : JsonSerializer.Deserialize<Transaction>(value!, JsonOptions);
    }

    /// <summary>
    /// Crea una transaccion guardando sus datos y agregando su identificador al indice de Redis.
    /// </summary>
    public async Task CreateAsync(Transaction transaction)
    {
        await SaveAsync(transaction);
        await database.SetAddAsync(IndexKey, transaction.Id);
    }

    /// <summary>
    /// Actualiza una transaccion existente sobrescribiendo su valor almacenado en Redis.
    /// </summary>
    public Task UpdateAsync(Transaction transaction)
    {
        return SaveAsync(transaction);
    }

    /// <summary>
    /// Elimina una transaccion por identificador y la retira del indice si la clave fue borrada.
    /// </summary>
    public async Task<bool> DeleteAsync(string id)
    {
        var deleted = await database.KeyDeleteAsync(GetKey(id));
        if (deleted)
        {
            await database.SetRemoveAsync(IndexKey, id);
        }

        return deleted;
    }

    /// <summary>
    /// Serializa una transaccion y la guarda en Redis usando la clave construida con su identificador.
    /// </summary>
    private Task<bool> SaveAsync(Transaction transaction)
    {
        var json = JsonSerializer.Serialize(transaction, JsonOptions);
        return database.StringSetAsync(GetKey(transaction.Id), json);
    }

    /// <summary>
    /// Construye la clave Redis usada para almacenar una transaccion individual.
    /// </summary>
    private static string GetKey(string id)
    {
        return $"{KeyPrefix}{id}";
    }
}

/*
 * Proposito: define el contrato HTTP para crear una transaccion desde la API.
 * Entradas: Description, Amount, Type y Date enviados en el cuerpo JSON del POST.
 * Salidas: no produce salida directa; se transforma en CreateTransactionCommand en los endpoints.
 * Dependencias: usa TransactionType del dominio para mantener tipos validos de negocio.
 * Calidad: aplica Clean Code con un record inmutable, tipado fuerte y responsabilidad unica.
 */
using Back.Domain.Transactions;

namespace Back.Api.Contracts;

public sealed record CreateTransactionRequest(
    string Description,
    decimal Amount,
    TransactionType Type,
    DateTimeOffset? Date);

/*
 * Proposito: define el contrato HTTP para actualizar una transaccion existente.
 * Entradas: Description, Amount, Type y Date enviados en el cuerpo JSON del PUT.
 * Salidas: no produce salida directa; se transforma en UpdateTransactionCommand en los endpoints.
 * Dependencias: usa TransactionType del dominio para evitar valores de tipo no controlados.
 * Calidad: aplica Clean Code con un DTO inmutable, claro y separado de la logica de negocio.
 */
using Back.Domain.Transactions;

namespace Back.Api.Contracts;

public sealed record UpdateTransactionRequest(
    string Description,
    decimal Amount,
    TransactionType Type,
    DateTimeOffset? Date);

/*
 * Proposito: expone los endpoints REST para listar, consultar, crear, actualizar y eliminar transacciones.
 * Entradas: parametros de ruta, contratos HTTP y servicios de casos de uso inyectados por DI.
 * Salidas: respuestas HTTP Ok, Created, NoContent, NotFound o BadRequest segun el resultado.
 * Dependencias: depende de contratos API y casos de uso de Application, sin conocer Redis ni infraestructura.
 * Calidad: cumple Clean Architecture, mantiene endpoints delgados y delega reglas de negocio a casos de uso.
 */
using Back.Api.Contracts;
using Back.Application.Transactions.Commands;
using Back.Application.Transactions.UseCases;

namespace Back.Api.Endpoints;

public static class TransactionEndpoints
{
    public static IEndpointRouteBuilder MapTransactionEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/transactions").WithTags("Transactions");

        group.MapGet("/", async (IListTransactionsUseCase useCase) =>
        {
            var transactions = await useCase.ExecuteAsync();
            return Results.Ok(transactions);
        })
        .WithName("GetTransactions")
        .WithOpenApi();

        group.MapGet("/{id}", async (string id, IGetTransactionUseCase useCase) =>
        {
            var transaction = await useCase.ExecuteAsync(id);
            return transaction is null ? Results.NotFound() : Results.Ok(transaction);
        })
        .WithName("GetTransactionById")
        .WithOpenApi();

        group.MapPost("/", async (CreateTransactionRequest request, ICreateTransactionUseCase useCase) =>
        {
            var command = new CreateTransactionCommand(
                request.Description,
                request.Amount,
                request.Type,
                request.Date);

            var result = await useCase.ExecuteAsync(command);

            return result.IsSuccess
                ? Results.Created($"/api/transactions/{result.Value!.Id}", result.Value)
                : Results.BadRequest(new { message = result.Error });
        })
        .WithName("CreateTransaction")
        .WithOpenApi();

        group.MapPut("/{id}", async (string id, UpdateTransactionRequest request, IUpdateTransactionUseCase useCase) =>
        {
            var command = new UpdateTransactionCommand(
                id,
                request.Description,
                request.Amount,
                request.Type,
                request.Date);

            var result = await useCase.ExecuteAsync(command);

            if (result.NotFound)
            {
                return Results.NotFound();
            }

            return result.IsSuccess
                ? Results.Ok(result.Value)
                : Results.BadRequest(new { message = result.Error });
        })
        .WithName("UpdateTransaction")
        .WithOpenApi();

        group.MapDelete("/{id}", async (string id, IDeleteTransactionUseCase useCase) =>
        {
            var deleted = await useCase.ExecuteAsync(id);
            return deleted ? Results.NoContent() : Results.NotFound();
        })
        .WithName("DeleteTransaction")
        .WithOpenApi();

        return endpoints;
    }
}

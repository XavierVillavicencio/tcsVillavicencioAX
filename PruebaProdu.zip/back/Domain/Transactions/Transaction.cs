/*
 * Proposito: modela la entidad de negocio Transaction y sus operaciones de creacion y actualizacion.
 * Entradas: descripcion, monto, tipo y fecha opcional para construir o modificar una transaccion.
 * Salidas: instancias inmutables de Transaction con Id, datos normalizados y fecha resuelta.
 * Dependencias: usa TransactionType y tipos base de .NET; no depende de API ni infraestructura.
 * Calidad: protege invariantes simples, usa inmutabilidad y concentra comportamiento del dominio.
 */
namespace Back.Domain.Transactions;

public sealed record Transaction(
    string Id,
    string Description,
    decimal Amount,
    TransactionType Type,
    DateTimeOffset Date)
{
    public static Transaction Create(
        string description,
        decimal amount,
        TransactionType type,
        DateTimeOffset? date)
    {
        return new Transaction(
            Guid.NewGuid().ToString("N"),
            description.Trim(),
            amount,
            type,
            ResolveDate(date));
    }

    public Transaction Update(
        string description,
        decimal amount,
        TransactionType type,
        DateTimeOffset? date)
    {
        return this with
        {
            Description = description.Trim(),
            Amount = amount,
            Type = type,
            Date = date is null ? Date : ResolveDate(date)
        };
    }

    private static DateTimeOffset ResolveDate(DateTimeOffset? date)
    {
        if (date is null)
        {
            return DateTimeOffset.Now;
        }

        var requestedDate = date.Value;
        if (requestedDate.TimeOfDay != TimeSpan.Zero)
        {
            return requestedDate;
        }

        var currentTime = DateTimeOffset.Now.ToOffset(requestedDate.Offset);

        return new DateTimeOffset(
            requestedDate.Year,
            requestedDate.Month,
            requestedDate.Day,
            currentTime.Hour,
            currentTime.Minute,
            currentTime.Second,
            requestedDate.Offset);
    }
}

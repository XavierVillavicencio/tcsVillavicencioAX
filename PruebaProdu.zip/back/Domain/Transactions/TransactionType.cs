/*
 * Proposito: enumera los tipos de movimiento permitidos para una transaccion.
 * Entradas: no recibe datos; define valores Debit y Credit.
 * Salidas: valores tipados usados por contratos, comandos, dominio y persistencia.
 * Dependencias: no depende de otros componentes.
 * Calidad: evita strings magicos y mejora seguridad de tipos en todo el flujo.
 */
namespace Back.Domain.Transactions;

public enum TransactionType
{
    Debit,
    Credit
}

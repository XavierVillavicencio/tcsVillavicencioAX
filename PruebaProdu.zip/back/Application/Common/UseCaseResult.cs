/*
 * Proposito: representa el resultado estandar de un caso de uso con exito, error o recurso no encontrado.
 * Entradas: valor opcional, mensaje de error opcional y bandera NotFound.
 * Salidas: estado IsSuccess y fabricas Success, Failure y Missing para respuestas consistentes.
 * Dependencias: no depende de infraestructura ni API; es reutilizable dentro de Application.
 * Calidad: reduce duplicacion, hace explicitos los estados y mejora legibilidad de los flujos.
 */
namespace Back.Application.Common;

public sealed record UseCaseResult<T>(T? Value, string? Error, bool NotFound = false)
{
    public bool IsSuccess => Error is null && !NotFound;

    public static UseCaseResult<T> Success(T value)
    {
        return new UseCaseResult<T>(value, null);
    }

    public static UseCaseResult<T> Failure(string error)
    {
        return new UseCaseResult<T>(default, error);
    }

    public static UseCaseResult<T> Missing()
    {
        return new UseCaseResult<T>(default, null, true);
    }
}

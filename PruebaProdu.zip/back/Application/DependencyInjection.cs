/*
 * Proposito: registra los casos de uso de la capa Application en el contenedor de dependencias.
 * Entradas: IServiceCollection recibido durante el arranque de la API.
 * Salidas: IServiceCollection con servicios de transacciones disponibles para inyeccion.
 * Dependencias: depende solo de interfaces e implementaciones de casos de uso de Application.
 * Calidad: favorece inversion de dependencias, bajo acoplamiento y composicion explicita.
 */
using Back.Application.Transactions.UseCases;
using Microsoft.Extensions.DependencyInjection;

namespace Back.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<IListTransactionsUseCase, ListTransactionsUseCase>();
        services.AddScoped<IGetTransactionUseCase, GetTransactionUseCase>();
        services.AddScoped<ICreateTransactionUseCase, CreateTransactionUseCase>();
        services.AddScoped<IUpdateTransactionUseCase, UpdateTransactionUseCase>();
        services.AddScoped<IDeleteTransactionUseCase, DeleteTransactionUseCase>();

        return services;
    }
}

/*
 * Proposito: ejecuta el flujo de creacion de una transaccion.
 * Entradas: CreateTransactionCommand con descripcion, monto, tipo y fecha opcional.
 * Salidas: UseCaseResult<Transaction> con la transaccion creada o un error de validacion.
 * Dependencias: usa TransactionValidator, la entidad Transaction y el puerto ITransactionRepository.
 * Calidad: separa reglas de aplicacion de API e infraestructura, con dependencias inyectadas y flujo claro.
 */
using Back.Application.Common;
using Back.Application.Transactions.Commands;
using Back.Application.Transactions.Ports;
using Back.Application.Transactions.Services;
using Back.Domain.Transactions;

namespace Back.Application.Transactions.UseCases;

public interface ICreateTransactionUseCase
{
    Task<UseCaseResult<Transaction>> ExecuteAsync(CreateTransactionCommand command);
}

public sealed class CreateTransactionUseCase : ICreateTransactionUseCase
{
    private readonly ITransactionRepository repository;

    public CreateTransactionUseCase(ITransactionRepository repository)
    {
        this.repository = repository;
    }

    public async Task<UseCaseResult<Transaction>> ExecuteAsync(CreateTransactionCommand command)
    {
        var validationError = TransactionValidator.Validate(command);
        if (validationError is not null)
        {
            return UseCaseResult<Transaction>.Failure(validationError);
        }

        var transaction = Transaction.Create(
            command.Description,
            command.Amount,
            command.Type,
            command.Date);

        await repository.CreateAsync(transaction);

        return UseCaseResult<Transaction>.Success(transaction);
    }
}

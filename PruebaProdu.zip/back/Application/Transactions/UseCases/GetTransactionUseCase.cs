/*
 * Proposito: obtiene una transaccion especifica por identificador.
 * Entradas: id de la transaccion solicitada.
 * Salidas: Transaction si existe o null si no se encuentra.
 * Dependencias: usa ITransactionRepository y la entidad Transaction del dominio.
 * Calidad: aplica bajo acoplamiento y mantiene un caso de uso pequeno y facil de probar.
 */
using Back.Application.Transactions.Ports;
using Back.Domain.Transactions;

namespace Back.Application.Transactions.UseCases;

public interface IGetTransactionUseCase
{
    Task<Transaction?> ExecuteAsync(string id);
}

public sealed class GetTransactionUseCase : IGetTransactionUseCase
{
    private readonly ITransactionRepository repository;

    public GetTransactionUseCase(ITransactionRepository repository)
    {
        this.repository = repository;
    }

    public Task<Transaction?> ExecuteAsync(string id)
    {
        return repository.GetByIdAsync(id);
    }
}

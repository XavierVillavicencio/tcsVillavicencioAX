/*
 * Proposito: ejecuta el flujo de actualizacion de una transaccion existente.
 * Entradas: UpdateTransactionCommand con id y nuevos datos de la transaccion.
 * Salidas: UseCaseResult<Transaction> con entidad actualizada, error de validacion o NotFound.
 * Dependencias: usa TransactionValidator, Transaction e ITransactionRepository.
 * Calidad: separa validacion, busqueda, actualizacion y persistencia en pasos legibles.
 */
using Back.Application.Common;
using Back.Application.Transactions.Commands;
using Back.Application.Transactions.Ports;
using Back.Application.Transactions.Services;
using Back.Domain.Transactions;

namespace Back.Application.Transactions.UseCases;

public interface IUpdateTransactionUseCase
{
    Task<UseCaseResult<Transaction>> ExecuteAsync(UpdateTransactionCommand command);
}

public sealed class UpdateTransactionUseCase : IUpdateTransactionUseCase
{
    private readonly ITransactionRepository repository;

    public UpdateTransactionUseCase(ITransactionRepository repository)
    {
        this.repository = repository;
    }

    public async Task<UseCaseResult<Transaction>> ExecuteAsync(UpdateTransactionCommand command)
    {
        var validationError = TransactionValidator.Validate(command);
        if (validationError is not null)
        {
            return UseCaseResult<Transaction>.Failure(validationError);
        }

        var existing = await repository.GetByIdAsync(command.Id);
        if (existing is null)
        {
            return UseCaseResult<Transaction>.Missing();
        }

        var updated = existing.Update(
            command.Description,
            command.Amount,
            command.Type,
            command.Date);

        await repository.UpdateAsync(updated);

        return UseCaseResult<Transaction>.Success(updated);
    }
}

/*
 * Proposito: ejecuta el flujo de eliminacion de una transaccion por identificador.
 * Entradas: id de la transaccion a eliminar.
 * Salidas: booleano que indica si la transaccion fue eliminada.
 * Dependencias: usa el puerto ITransactionRepository para desacoplarse de la persistencia concreta.
 * Calidad: mantiene responsabilidad unica y delega detalles de almacenamiento al repositorio.
 */
using Back.Application.Transactions.Ports;

namespace Back.Application.Transactions.UseCases;

public interface IDeleteTransactionUseCase
{
    Task<bool> ExecuteAsync(string id);
}

public sealed class DeleteTransactionUseCase : IDeleteTransactionUseCase
{
    private readonly ITransactionRepository repository;

    public DeleteTransactionUseCase(ITransactionRepository repository)
    {
        this.repository = repository;
    }

    public Task<bool> ExecuteAsync(string id)
    {
        return repository.DeleteAsync(id);
    }
}

/*
 * Proposito: obtiene el listado completo de transacciones disponibles.
 * Entradas: no recibe parametros de negocio.
 * Salidas: coleccion de Transaction entregada por el repositorio.
 * Dependencias: usa ITransactionRepository y la entidad Transaction del dominio.
 * Calidad: cumple responsabilidad unica y facilita pruebas al depender de una interfaz.
 */
using Back.Application.Transactions.Ports;
using Back.Domain.Transactions;

namespace Back.Application.Transactions.UseCases;

public interface IListTransactionsUseCase
{
    Task<IReadOnlyCollection<Transaction>> ExecuteAsync();
}

public sealed class ListTransactionsUseCase : IListTransactionsUseCase
{
    private readonly ITransactionRepository repository;

    public ListTransactionsUseCase(ITransactionRepository repository)
    {
        this.repository = repository;
    }

    public Task<IReadOnlyCollection<Transaction>> ExecuteAsync()
    {
        return repository.GetAllAsync();
    }
}

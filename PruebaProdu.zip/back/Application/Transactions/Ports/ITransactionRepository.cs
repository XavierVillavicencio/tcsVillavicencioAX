/*
 * Proposito: define el puerto de persistencia requerido por los casos de uso de transacciones.
 * Entradas: identificadores y entidades Transaction segun la operacion solicitada.
 * Salidas: colecciones, entidades opcionales o confirmaciones booleanas de eliminacion.
 * Dependencias: depende del dominio, no de Redis ni de detalles externos.
 * Calidad: aplica inversion de dependencias y permite cambiar la persistencia sin afectar Application.
 */
using Back.Domain.Transactions;

namespace Back.Application.Transactions.Ports;

public interface ITransactionRepository
{
    Task<IReadOnlyCollection<Transaction>> GetAllAsync();
    Task<Transaction?> GetByIdAsync(string id);
    Task CreateAsync(Transaction transaction);
    Task UpdateAsync(Transaction transaction);
    Task<bool> DeleteAsync(string id);
}

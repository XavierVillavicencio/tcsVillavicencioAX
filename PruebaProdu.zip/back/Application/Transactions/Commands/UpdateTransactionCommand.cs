/*
 * Proposito: transporta los datos necesarios para actualizar una transaccion existente.
 * Entradas: Id, Description, Amount, Type y Date.
 * Salidas: no produce salida directa; es consumido por UpdateTransactionUseCase.
 * Dependencias: usa TransactionType del dominio para limitar tipos validos.
 * Calidad: mantiene responsabilidad unica y evita mezclar transporte HTTP con reglas de aplicacion.
 */
using Back.Domain.Transactions;

namespace Back.Application.Transactions.Commands;

public sealed record UpdateTransactionCommand(
    string Id,
    string Description,
    decimal Amount,
    TransactionType Type,
    DateTimeOffset? Date);

/*
 * Proposito: transporta los datos necesarios para ejecutar la creacion de una transaccion.
 * Entradas: Description, Amount, Type y Date provenientes del contrato HTTP.
 * Salidas: no produce salida directa; es consumido por CreateTransactionUseCase.
 * Dependencias: usa TransactionType del dominio para mantener consistencia de negocio.
 * Calidad: aplica Clean Code con un comando inmutable y separado del contrato externo de API.
 */
using Back.Domain.Transactions;

namespace Back.Application.Transactions.Commands;

public sealed record CreateTransactionCommand(
    string Description,
    decimal Amount,
    TransactionType Type,
    DateTimeOffset? Date);

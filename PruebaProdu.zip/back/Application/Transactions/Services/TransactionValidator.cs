/*
 * Proposito: valida reglas basicas de entrada para crear y actualizar transacciones.
 * Entradas: CreateTransactionCommand o UpdateTransactionCommand.
 * Salidas: mensaje de error si hay datos invalidos o null si la entrada es valida.
 * Dependencias: depende de los comandos de Application y del enum de tipo por validacion.
 * Calidad: centraliza validaciones, evita duplicacion y mantiene casos de uso mas legibles.
 */
using Back.Application.Transactions.Commands;

namespace Back.Application.Transactions.Services;

public static class TransactionValidator
{
    public static string? Validate(CreateTransactionCommand command)
    {
        if (string.IsNullOrWhiteSpace(command.Description))
        {
            return "La descripcion es obligatoria.";
        }

        if (command.Amount <= 0)
        {
            return "El monto debe ser numerico y mayor a cero.";
        }

        if (!Enum.IsDefined(command.Type))
        {
            return "El tipo de transaccion debe ser Debit o Credit.";
        }

        return null;
    }

    public static string? Validate(UpdateTransactionCommand command)
    {
        if (string.IsNullOrWhiteSpace(command.Description))
        {
            return "La descripcion es obligatoria.";
        }

        if (command.Amount <= 0)
        {
            return "El monto debe ser numerico y mayor a cero.";
        }

        if (!Enum.IsDefined(command.Type))
        {
            return "El tipo de transaccion debe ser Debit o Credit.";
        }

        return null;
    }
}

/*
 * Proposito: configura y arranca la API ASP.NET Core.
 * Entradas: configuracion de la aplicacion, connection strings y solicitudes HTTP entrantes.
 * Salidas: servidor web con Swagger, CORS, serializacion JSON y endpoints de transacciones registrados.
 * Dependencias: usa las extensiones de Application, Infrastructure y los endpoints API.
 * Calidad: centraliza la composicion de dependencias y mantiene separadas las capas por responsabilidad.
 */
using Back.Api.Endpoints;
using Back.Application;
using Back.Infrastructure;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("AngularDev", policy =>
    {
        policy
            .WithOrigins("http://localhost:4200", "https://localhost:4200")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.Use(async (context, next) =>
{
    try
    {
        await next(context);
    }
    catch (BadHttpRequestException exception) when (exception.InnerException is JsonException jsonException)
    {
        if (context.Response.HasStarted)
        {
            throw;
        }

        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        context.Response.ContentType = "application/json";

        await context.Response.WriteAsJsonAsync(new
        {
            message = "El cuerpo de la solicitud no es un JSON valido.",
            error = "Revisa que las propiedades usen comillas dobles y que los numeros decimales usen punto, por ejemplo 150.99.",
            details = $"Error cerca de la linea {jsonException.LineNumber + 1}, posicion {jsonException.BytePositionInLine + 1}."
        });
    }
});

app.UseCors("AngularDev");
app.MapTransactionEndpoints();

app.Run();

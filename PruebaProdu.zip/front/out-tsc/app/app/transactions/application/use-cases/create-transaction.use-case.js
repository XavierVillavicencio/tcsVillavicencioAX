import { __decorate } from "tslib";
import { inject, Injectable } from '@angular/core';
import { TRANSACTION_REPOSITORY } from '../ports/transaction-repository.port';
let CreateTransactionUseCase = class CreateTransactionUseCase {
    repository = inject(TRANSACTION_REPOSITORY);
    execute(command) {
        return this.repository.create({
            ...command,
            description: command.description.trim(),
        });
    }
};
CreateTransactionUseCase = __decorate([
    Injectable({ providedIn: 'root' })
], CreateTransactionUseCase);
export { CreateTransactionUseCase };

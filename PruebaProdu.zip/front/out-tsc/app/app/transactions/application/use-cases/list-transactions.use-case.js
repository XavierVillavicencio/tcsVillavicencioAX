import { __decorate } from "tslib";
import { inject, Injectable } from '@angular/core';
import { map } from 'rxjs';
import { sortTransactionsByDateDesc } from '../../domain/transaction-calculator';
import { TRANSACTION_REPOSITORY } from '../ports/transaction-repository.port';
let ListTransactionsUseCase = class ListTransactionsUseCase {
    repository = inject(TRANSACTION_REPOSITORY);
    execute() {
        return this.repository.findAll().pipe(map(sortTransactionsByDateDesc));
    }
};
ListTransactionsUseCase = __decorate([
    Injectable({ providedIn: 'root' })
], ListTransactionsUseCase);
export { ListTransactionsUseCase };

import { InjectionToken } from '@angular/core';
export const TRANSACTION_REPOSITORY = new InjectionToken('TRANSACTION_REPOSITORY');

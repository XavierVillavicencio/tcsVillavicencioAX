export function calculateTransactionTotals(transactions) {
    return transactions.reduce((summary, transaction) => {
        if (transaction.type === 'Credit') {
            summary.credits += transaction.amount;
        }
        else {
            summary.debits += transaction.amount;
        }
        summary.balance = summary.credits - summary.debits;
        return summary;
    }, { credits: 0, debits: 0, balance: 0 });
}
export function sortTransactionsByDateDesc(transactions) {
    return [...transactions].sort((current, next) => {
        return new Date(next.date).getTime() - new Date(current.date).getTime();
    });
}

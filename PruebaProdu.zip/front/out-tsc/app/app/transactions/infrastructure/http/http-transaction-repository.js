import { __decorate } from "tslib";
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
let HttpTransactionRepository = class HttpTransactionRepository {
    http = inject(HttpClient);
    apiUrl = 'http://localhost:5134/api/transactions';
    findAll() {
        return this.http.get(this.apiUrl);
    }
    findById(id) {
        return this.http.get(`${this.apiUrl}/${id}`);
    }
    create(command) {
        return this.http.post(this.apiUrl, command);
    }
    update(id, command) {
        return this.http.put(`${this.apiUrl}/${id}`, command);
    }
    delete(id) {
        return this.http.delete(`${this.apiUrl}/${id}`);
    }
};
HttpTransactionRepository = __decorate([
    Injectable()
], HttpTransactionRepository);
export { HttpTransactionRepository };

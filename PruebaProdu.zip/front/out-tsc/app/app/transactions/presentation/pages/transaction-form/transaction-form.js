import { __decorate } from "tslib";
import { Component, inject, signal } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { CreateTransactionUseCase } from '../../../application/use-cases/create-transaction.use-case';
let TransactionFormPage = class TransactionFormPage {
    formBuilder = inject(NonNullableFormBuilder);
    router = inject(Router);
    createTransaction = inject(CreateTransactionUseCase);
    today = new Date().toISOString().slice(0, 10);
    errorMessage = signal('');
    submitting = signal(false);
    form = this.formBuilder.group({
        description: ['', [Validators.required, Validators.minLength(3)]],
        type: ['Debit', Validators.required],
        amount: [0, [Validators.required, Validators.min(0.01)]],
        date: [this.today, Validators.required],
    });
    async submit() {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            return;
        }
        const formValue = this.form.getRawValue();
        this.errorMessage.set('');
        this.submitting.set(true);
        try {
            await firstValueFrom(this.createTransaction.execute({
                description: formValue.description.trim(),
                type: formValue.type,
                amount: Number(formValue.amount),
                date: this.toDateTimeOffset(formValue.date),
            }));
            await this.router.navigateByUrl('/resumen');
        }
        catch {
            this.errorMessage.set('No se pudo guardar la transacción. Verifica que el backend esté disponible.');
            this.submitting.set(false);
        }
    }
    clear() {
        this.errorMessage.set('');
        this.form.reset({
            description: '',
            type: 'Debit',
            amount: 0,
            date: this.today,
        });
    }
    hasError(controlName) {
        const control = this.form.controls[controlName];
        return control.invalid && (control.dirty || control.touched);
    }
    toDateTimeOffset(date) {
        return `${date}T00:00:00-05:00`;
    }
};
TransactionFormPage = __decorate([
    Component({
        selector: 'app-transaction-form',
        imports: [ReactiveFormsModule],
        templateUrl: './transaction-form.html',
    })
], TransactionFormPage);
export { TransactionFormPage };

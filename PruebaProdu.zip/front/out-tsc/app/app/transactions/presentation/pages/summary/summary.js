import { __decorate } from "tslib";
import { CurrencyPipe } from '@angular/common';
import { Component, computed, DestroyRef, inject, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { ListTransactionsUseCase } from '../../../application/use-cases/list-transactions.use-case';
import { calculateTransactionTotals } from '../../../domain/transaction-calculator';
let SummaryPage = class SummaryPage {
    destroyRef = inject(DestroyRef);
    listTransactions = inject(ListTransactionsUseCase);
    transactions = signal([]);
    loading = signal(true);
    errorMessage = signal('');
    totals = computed(() => calculateTransactionTotals(this.transactions()));
    ngOnInit() {
        this.loadTransactions();
    }
    formatDate(value) {
        const [year, month, day] = value.slice(0, 10).split('-');
        const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
        return `${day} ${monthNames[Number(month) - 1]} ${year}`;
    }
    amountPrefix(transaction) {
        return transaction.type === 'Debit' ? '-' : '';
    }
    typeLabel(transaction) {
        return transaction.type === 'Credit' ? 'Crédito' : 'Débito';
    }
    loadTransactions() {
        this.loading.set(true);
        this.errorMessage.set('');
        this.listTransactions
            .execute()
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
            next: (transactions) => {
                this.transactions.set(transactions);
                this.loading.set(false);
            },
            error: () => {
                this.errorMessage.set('No se pudieron cargar las transacciones. Verifica que el backend esté disponible.');
                this.loading.set(false);
            },
        });
    }
};
SummaryPage = __decorate([
    Component({
        selector: 'app-summary',
        imports: [CurrencyPipe, RouterLink],
        templateUrl: './summary.html',
    })
], SummaryPage);
export { SummaryPage };

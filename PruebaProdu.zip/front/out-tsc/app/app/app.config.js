import { provideHttpClient } from '@angular/common/http';
import { provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
import { TRANSACTION_REPOSITORY } from './transactions/application/ports/transaction-repository.port';
import { HttpTransactionRepository } from './transactions/infrastructure/http/http-transaction-repository';
export const appConfig = {
    providers: [
        provideBrowserGlobalErrorListeners(),
        provideRouter(routes),
        provideHttpClient(),
        {
            provide: TRANSACTION_REPOSITORY,
            useClass: HttpTransactionRepository,
        },
    ],
};

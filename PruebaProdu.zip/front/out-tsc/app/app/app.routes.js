export const routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'resumen',
    },
    {
        path: 'resumen',
        loadComponent: () => import('./transactions/presentation/pages/summary/summary').then((page) => page.SummaryPage),
    },
    {
        path: 'transaccion',
        loadComponent: () => import('./transactions/presentation/pages/transaction-form/transaction-form').then((page) => page.TransactionFormPage),
    },
    {
        path: '**',
        redirectTo: 'resumen',
    },
];

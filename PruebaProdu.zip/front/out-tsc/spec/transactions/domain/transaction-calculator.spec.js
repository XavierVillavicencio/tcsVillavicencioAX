import { calculateTransactionTotals, sortTransactionsByDateDesc } from './transaction-calculator';
const transactions = [
    {
        id: '1',
        description: 'Compra',
        amount: 20,
        type: 'Debit',
        date: '2026-06-04T00:00:00-05:00',
    },
    {
        id: '2',
        description: 'Deposito',
        amount: 100,
        type: 'Credit',
        date: '2026-06-06T00:00:00-05:00',
    },
];
describe('transaction calculator', () => {
    it('calculates credits, debits and balance', () => {
        expect(calculateTransactionTotals(transactions)).toEqual({
            credits: 100,
            debits: 20,
            balance: 80,
        });
    });
    it('sorts transactions by date descending', () => {
        expect(sortTransactionsByDateDesc(transactions).map((transaction) => transaction.id)).toEqual(['2', '1']);
    });
});

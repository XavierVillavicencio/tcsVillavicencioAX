import { TestBed } from '@angular/core/testing';
import { firstValueFrom, of } from 'rxjs';
import { TRANSACTION_REPOSITORY } from '../ports/transaction-repository.port';
import { CreateTransactionUseCase } from './create-transaction.use-case';
import { ListTransactionsUseCase } from './list-transactions.use-case';
class FakeTransactionRepository {
    createCommand = null;
    findAll() {
        return of([
            {
                id: '1',
                description: 'Anterior',
                amount: 25,
                type: 'Debit',
                date: '2026-06-01T00:00:00-05:00',
            },
            {
                id: '2',
                description: 'Actual',
                amount: 75,
                type: 'Credit',
                date: '2026-06-05T00:00:00-05:00',
            },
        ]);
    }
    findById(id) {
        return of({
            id,
            description: 'Actual',
            amount: 75,
            type: 'Credit',
            date: '2026-06-05T00:00:00-05:00',
        });
    }
    create(command) {
        this.createCommand = command;
        return of({
            id: 'created-id',
            description: command.description,
            amount: command.amount,
            type: command.type,
            date: command.date ?? '2026-06-06T00:00:00-05:00',
        });
    }
    update(id, command) {
        return of({
            id,
            description: command.description,
            amount: command.amount,
            type: command.type,
            date: command.date ?? '2026-06-06T00:00:00-05:00',
        });
    }
    delete() {
        return of(undefined);
    }
}
describe('transaction use cases', () => {
    let repository;
    beforeEach(() => {
        repository = new FakeTransactionRepository();
        TestBed.configureTestingModule({
            providers: [
                {
                    provide: TRANSACTION_REPOSITORY,
                    useValue: repository,
                },
            ],
        });
    });
    it('lists transactions sorted by newest date first', async () => {
        const useCase = TestBed.inject(ListTransactionsUseCase);
        const result = await firstValueFrom(useCase.execute());
        expect(result.map((transaction) => transaction.id)).toEqual(['2', '1']);
    });
    it('trims the description before creating a transaction', async () => {
        const useCase = TestBed.inject(CreateTransactionUseCase);
        await firstValueFrom(useCase.execute({
            description: '  Pago servicio  ',
            amount: 50,
            type: 'Debit',
            date: '2026-06-06T00:00:00-05:00',
        }));
        expect(repository.createCommand).toEqual({
            description: 'Pago servicio',
            amount: 50,
            type: 'Debit',
            date: '2026-06-06T00:00:00-05:00',
        });
    });
});

/*
 * Proposito: define la navegacion principal de la aplicacion.
 * Entradas: URL solicitada por el usuario.
 * Salidas: componente lazy-loaded correspondiente o redireccion a resumen.
 * Dependencias: depende de Angular Router y de las paginas de transacciones cargadas bajo demanda.
 * Calidad: mejora rendimiento con lazy loading y mantiene rutas simples y declarativas.
 */
import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'resumen',
  },
  {
    path: 'resumen',
    loadComponent: () =>
      import('./transactions/presentation/pages/summary/summary').then((page) => page.SummaryPage),
  },
  {
    path: 'transaccion',
    loadComponent: () =>
      import('./transactions/presentation/pages/transaction-form/transaction-form').then(
        (page) => page.TransactionFormPage,
      ),
  },
  {
    path: '**',
    redirectTo: 'resumen',
  },
];

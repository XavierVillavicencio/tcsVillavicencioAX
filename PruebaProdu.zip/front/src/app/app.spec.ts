/*
 * Proposito: verifica que el componente raiz de Angular se pueda crear correctamente.
 * Entradas: TestBed con App y un Router vacio para satisfacer dependencias de navegacion.
 * Salidas: expectativa positiva sobre la instancia del componente.
 * Dependencias: usa Angular Testing y provideRouter.
 * Calidad: aporta prueba smoke para detectar errores de bootstrap, imports o template.
 */
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { App } from './app';

describe('App', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([])],
    }).compileComponents();
  });

  it('should create the app shell', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });
});

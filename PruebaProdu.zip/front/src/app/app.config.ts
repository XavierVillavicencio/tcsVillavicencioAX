/*
 * Proposito: configura los proveedores globales de la aplicacion Angular.
 * Entradas: rutas, cliente HTTP y token de repositorio de transacciones.
 * Salidas: ApplicationConfig usado por el bootstrap de Angular.
 * Dependencias: depende de Router, HttpClient y HttpTransactionRepository.
 * Calidad: centraliza la composicion, usa inyeccion de dependencias y mantiene bajo acoplamiento.
 */
import { provideHttpClient } from '@angular/common/http';
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { TRANSACTION_REPOSITORY } from './transactions/application/ports/transaction-repository.port';
import { HttpTransactionRepository } from './transactions/infrastructure/http/http-transaction-repository';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(),
    {
      provide: TRANSACTION_REPOSITORY,
      useClass: HttpTransactionRepository,
    },
  ],
};

/*
 * Proposito: implementa el repositorio de transacciones usando HTTP contra la API backend.
 * Entradas: comandos, identificadores y llamadas de consulta desde los casos de uso.
 * Salidas: Observables con respuestas tipadas de la API.
 * Dependencias: usa Angular HttpClient y cumple TransactionRepositoryPort.
 * Calidad: encapsula URLs y protocolo HTTP para mantener Application independiente de infraestructura.
 */
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { CreateTransactionCommand, Transaction } from '../../domain/transaction';
import { TransactionRepositoryPort } from '../../application/ports/transaction-repository.port';

@Injectable()
export class HttpTransactionRepository implements TransactionRepositoryPort {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = '/api/transactions';

  findAll(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.apiUrl);
  }

  findById(id: string): Observable<Transaction> {
    return this.http.get<Transaction>(`${this.apiUrl}/${id}`);
  }

  create(command: CreateTransactionCommand): Observable<Transaction> {
    return this.http.post<Transaction>(this.apiUrl, command);
  }

  update(id: string, command: CreateTransactionCommand): Observable<Transaction> {
    return this.http.put<Transaction>(`${this.apiUrl}/${id}`, command);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}

/*
 * Proposito: controla la pagina de resumen y prepara los datos para la tabla de transacciones.
 * Entradas: eventos de ciclo de vida y datos emitidos por ListTransactionsUseCase.
 * Salidas: senales de carga, error, transacciones, totales y filas con saldo para el template.
 * Dependencias: usa Angular signals, CurrencyPipe, RouterLink y el caso de uso de listado.
 * Calidad: separa estado de presentacion, libera suscripciones con DestroyRef y mantiene template simple.
 */
import { CurrencyPipe } from '@angular/common';
import { Component, computed, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';

import { ListTransactionsUseCase } from '../../../application/use-cases/list-transactions.use-case';
import { calculateTransactionTotals } from '../../../domain/transaction-calculator';
import { Transaction } from '../../../domain/transaction';

interface TransactionRow {
  transaction: Transaction;
  balance: number;
}

@Component({
  selector: 'app-summary',
  imports: [CurrencyPipe, RouterLink],
  templateUrl: './summary.html',
})
export class SummaryPage implements OnInit {
  private readonly destroyRef = inject(DestroyRef);
  private readonly listTransactions = inject(ListTransactionsUseCase);

  readonly transactions = signal<Transaction[]>([]);
  readonly loading = signal(true);
  readonly errorMessage = signal('');

  readonly totals = computed(() => calculateTransactionTotals(this.transactions()));
  readonly transactionRows = computed<TransactionRow[]>(() => {
    let balance = this.totals().balance;

    return this.transactions().map((transaction) => {
      const row = { transaction, balance };
      balance -= this.signedAmount(transaction);

      return row;
    });
  });

  ngOnInit(): void {
    this.loadTransactions();
  }

  formatDate(value: string): string {
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
      return value;
    }

    return new Intl.DateTimeFormat('es-EC', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).format(date);
  }

  amountPrefix(transaction: Transaction): string {
    return transaction.type === 'Debit' ? '-' : '';
  }

  typeLabel(transaction: Transaction): string {
    return transaction.type === 'Credit' ? 'Crédito' : 'Débito';
  }

  displayTransactionId(id: string, index: number): string {
    return /^\d+$/.test(id) ? id.padStart(3, '0') : String(index + 1).padStart(3, '0');
  }

  private loadTransactions(): void {
    this.loading.set(true);
    this.errorMessage.set('');

    this.listTransactions
      .execute()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (transactions) => {
          this.transactions.set(transactions);
          this.loading.set(false);
        },
        error: () => {
          this.errorMessage.set('No se pudieron cargar las transacciones. Verifica que el backend esté disponible.');
          this.loading.set(false);
        },
      });
  }

  private signedAmount(transaction: Transaction): number {
    return transaction.type === 'Debit' ? -transaction.amount : transaction.amount;
  }
}

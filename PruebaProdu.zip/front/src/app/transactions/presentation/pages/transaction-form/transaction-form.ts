/*
 * Proposito: controla el formulario para crear transacciones desde la UI.
 * Entradas: valores de formulario, clicks de enviar/limpiar y validaciones reactivas.
 * Salidas: llamada al caso de uso, mensajes de error, estado de envio y navegacion a resumen.
 * Dependencias: usa ReactiveFormsModule, Router, RxJS y CreateTransactionUseCase.
 * Calidad: valida del lado cliente, usa formularios tipados y mantiene la logica de envio encapsulada.
 */
import { Component, inject, signal } from '@angular/core';
import { AbstractControl, NonNullableFormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';

import { CreateTransactionUseCase } from '../../../application/use-cases/create-transaction.use-case';

@Component({
  selector: 'app-transaction-form',
  imports: [ReactiveFormsModule],
  templateUrl: './transaction-form.html',
})
export class TransactionFormPage {
  private readonly formBuilder = inject(NonNullableFormBuilder);
  private readonly router = inject(Router);
  private readonly createTransaction = inject(CreateTransactionUseCase);

  readonly today = new Date().toISOString().slice(0, 10);
  readonly errorMessage = signal('');
  readonly submitting = signal(false);

  readonly form = this.formBuilder.group({
    description: ['', [Validators.required, Validators.minLength(3)]],
    type: ['Debit', Validators.required],
    amount: ['', [Validators.required, Validators.min(0.01), this.maxTwoDecimalPlaces]],
    date: [this.today, Validators.required],
  });

  async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const formValue = this.form.getRawValue();

    this.errorMessage.set('');
    this.submitting.set(true);

    try {
      await firstValueFrom(
        this.createTransaction.execute({
          description: formValue.description.trim(),
          type: formValue.type as 'Debit' | 'Credit',
          amount: Number(formValue.amount),
          date: this.toDateTimeOffset(formValue.date),
        }),
      );

      await this.router.navigateByUrl('/resumen');
    } catch {
      this.errorMessage.set('No se pudo guardar la transacción. Verifica que el backend esté disponible.');
      this.submitting.set(false);
    }
  }

  clear(): void {
    this.errorMessage.set('');
    this.form.reset({
      description: '',
      type: 'Debit',
      amount: '',
      date: this.today,
    });
  }

  limitAmountDecimals(event: Event): void {
    const input = event.target as HTMLInputElement;
    const sanitizedValue = this.sanitizeAmount(input.value);

    if (input.value !== sanitizedValue) {
      input.value = sanitizedValue;
      this.form.controls.amount.setValue(sanitizedValue);
    }
  }

  hasError(controlName: keyof typeof this.form.controls): boolean {
    const control = this.form.controls[controlName];

    return control.invalid && (control.dirty || control.touched);
  }

  private maxTwoDecimalPlaces(control: AbstractControl<string>): ValidationErrors | null {
    const value = control.value;

    if (!value) {
      return null;
    }

    return /^\d+(\.\d{0,2})?$/.test(value) ? null : { maxTwoDecimalPlaces: true };
  }

  private sanitizeAmount(value: string): string {
    const normalizedValue = value.replace(',', '.').replace(/[^\d.]/g, '');
    const [integerPart, ...decimalParts] = normalizedValue.split('.');
    const integer = integerPart.replace(/^0+(?=\d)/, '');

    if (decimalParts.length === 0) {
      return integer;
    }

    const decimals = decimalParts.join('').slice(0, 2);

    return `${integer || '0'}.${decimals}`;
  }

  private toDateTimeOffset(date: string): string {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    return `${date}T${hours}:${minutes}:${seconds}-05:00`;
  }
}

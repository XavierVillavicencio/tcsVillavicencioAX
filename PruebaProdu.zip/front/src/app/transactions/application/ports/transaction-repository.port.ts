/*
 * Proposito: define el contrato que la aplicacion usa para acceder a transacciones.
 * Entradas: comandos de creacion/actualizacion e identificadores de transaccion.
 * Salidas: Observables con transacciones, listas o confirmacion void.
 * Dependencias: usa RxJS, InjectionToken y tipos del dominio frontend.
 * Calidad: aplica inversion de dependencias y permite cambiar HTTP por otra fuente sin afectar casos de uso.
 */
import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

import { CreateTransactionCommand, Transaction } from '../../domain/transaction';

export interface TransactionRepositoryPort {
  findAll(): Observable<Transaction[]>;
  findById(id: string): Observable<Transaction>;
  create(command: CreateTransactionCommand): Observable<Transaction>;
  update(id: string, command: CreateTransactionCommand): Observable<Transaction>;
  delete(id: string): Observable<void>;
}

export const TRANSACTION_REPOSITORY = new InjectionToken<TransactionRepositoryPort>('TRANSACTION_REPOSITORY');

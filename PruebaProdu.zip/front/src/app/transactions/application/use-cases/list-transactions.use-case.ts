/*
 * Proposito: obtiene transacciones y las ordena para presentarlas al usuario.
 * Entradas: no recibe parametros desde la UI.
 * Salidas: Observable<Transaction[]> ordenado por fecha descendente.
 * Dependencias: usa TransactionRepositoryPort, RxJS map y sortTransactionsByDateDesc.
 * Calidad: separa transformacion de datos de la vista y favorece funciones puras reutilizables.
 */
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

import { sortTransactionsByDateDesc } from '../../domain/transaction-calculator';
import { Transaction } from '../../domain/transaction';
import { TRANSACTION_REPOSITORY, TransactionRepositoryPort } from '../ports/transaction-repository.port';

@Injectable({ providedIn: 'root' })
export class ListTransactionsUseCase {
  private readonly repository = inject<TransactionRepositoryPort>(TRANSACTION_REPOSITORY);

  execute(): Observable<Transaction[]> {
    return this.repository.findAll().pipe(map(sortTransactionsByDateDesc));
  }
}

/*
 * Proposito: ejecuta el flujo frontend para crear una transaccion.
 * Entradas: CreateTransactionCommand desde el formulario.
 * Salidas: Observable<Transaction> emitido por el repositorio.
 * Dependencias: depende del puerto TransactionRepositoryPort mediante InjectionToken.
 * Calidad: normaliza datos de entrada, mantiene responsabilidad unica y desacopla UI de infraestructura.
 */
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { CreateTransactionCommand, Transaction } from '../../domain/transaction';
import { TRANSACTION_REPOSITORY, TransactionRepositoryPort } from '../ports/transaction-repository.port';

@Injectable({ providedIn: 'root' })
export class CreateTransactionUseCase {
  private readonly repository = inject<TransactionRepositoryPort>(TRANSACTION_REPOSITORY);

  execute(command: CreateTransactionCommand): Observable<Transaction> {
    return this.repository.create({
      ...command,
      description: command.description.trim(),
    });
  }
}

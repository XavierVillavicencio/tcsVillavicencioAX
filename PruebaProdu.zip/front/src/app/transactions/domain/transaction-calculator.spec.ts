/*
 * Proposito: prueba las funciones puras de calculo y ordenamiento de transacciones.
 * Entradas: arreglo fijo de Transaction usado como caso de prueba.
 * Salidas: expectativas sobre creditos, debitos, saldo y orden por fecha.
 * Dependencias: usa funciones del dominio y tipos Transaction.
 * Calidad: asegura reglas de negocio deterministicas con pruebas unitarias simples.
 */
import { calculateTransactionTotals, sortTransactionsByDateDesc } from './transaction-calculator';
import { Transaction } from './transaction';

const transactions: Transaction[] = [
  {
    id: '1',
    description: 'Compra',
    amount: 20,
    type: 'Debit',
    date: '2026-06-04T00:00:00-05:00',
  },
  {
    id: '2',
    description: 'Deposito',
    amount: 100,
    type: 'Credit',
    date: '2026-06-06T00:00:00-05:00',
  },
];

describe('transaction calculator', () => {
  it('calculates credits, debits and balance', () => {
    expect(calculateTransactionTotals(transactions)).toEqual({
      credits: 100,
      debits: 20,
      balance: 80,
    });
  });

  it('sorts transactions by date descending', () => {
    expect(sortTransactionsByDateDesc(transactions).map((transaction) => transaction.id)).toEqual(['2', '1']);
  });
});

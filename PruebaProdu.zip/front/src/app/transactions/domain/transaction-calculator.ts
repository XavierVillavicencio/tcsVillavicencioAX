/*
 * Proposito: contiene funciones puras para calcular totales y ordenar transacciones.
 * Entradas: arreglos de Transaction recibidos desde repositorios o casos de uso.
 * Salidas: TransactionTotals o un nuevo arreglo ordenado sin mutar el original.
 * Dependencias: depende solo de tipos del dominio frontend.
 * Calidad: aplica Clean Code con funciones puras, predecibles, testeables y sin efectos secundarios.
 */
import { Transaction, TransactionTotals } from './transaction';

export function calculateTransactionTotals(transactions: Transaction[]): TransactionTotals {
  return transactions.reduce(
    (summary, transaction) => {
      if (transaction.type === 'Credit') {
        summary.credits += transaction.amount;
      } else {
        summary.debits += transaction.amount;
      }

      summary.balance = summary.credits - summary.debits;

      return summary;
    },
    { credits: 0, debits: 0, balance: 0 },
  );
}

export function sortTransactionsByDateDesc(transactions: Transaction[]): Transaction[] {
  return [...transactions].sort((current, next) => {
    return new Date(next.date).getTime() - new Date(current.date).getTime();
  });
}

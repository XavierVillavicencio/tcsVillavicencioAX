/*
 * Proposito: define los tipos centrales del dominio de transacciones en el frontend.
 * Entradas: datos tipados provenientes de formularios, API y calculos de UI.
 * Salidas: contratos TypeScript para transacciones, comandos y totales.
 * Dependencias: no depende de Angular ni infraestructura.
 * Calidad: evita tipos implicitos, documenta el modelo compartido y mejora seguridad estatica.
 */
export type TransactionType = 'Debit' | 'Credit';

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  type: TransactionType;
  date: string;
}

export interface CreateTransactionCommand {
  description: string;
  amount: number;
  type: TransactionType;
  date: string | null;
}

export interface TransactionTotals {
  credits: number;
  debits: number;
  balance: number;
}

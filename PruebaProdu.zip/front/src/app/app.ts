/*
 * Proposito: controla el layout principal, el modo oscuro y el estado del menu lateral.
 * Entradas: clicks del usuario para cambiar tema o contraer/expandir menu.
 * Salidas: senales que actualizan clases del template y persistencia del tema en localStorage.
 * Dependencias: usa Angular signals, RouterLink/RouterOutlet, NgClass e iconos Lucide.
 * Calidad: mantiene estado local encapsulado, template declarativo y controles accesibles.
 */
import { NgClass } from '@angular/common';
import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import {
  LucideBell,
  LucideChevronLeft,
  LucideChevronRight,
  LucideCreditCard,
  LucideFileText,
  LucideMoon,
  LucideSun,
} from '@lucide/angular';

@Component({
  selector: 'app-root',
  imports: [
    NgClass,
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    LucideBell,
    LucideChevronLeft,
    LucideChevronRight,
    LucideCreditCard,
    LucideFileText,
    LucideMoon,
    LucideSun,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly isDarkMode = signal(this.getInitialTheme());
  readonly isMenuCollapsed = signal(false);

  constructor() {
    this.applyTheme(this.isDarkMode());
  }

  toggleTheme(): void {
    const nextTheme = !this.isDarkMode();

    this.isDarkMode.set(nextTheme);
    this.applyTheme(nextTheme);
  }

  toggleMenu(): void {
    this.isMenuCollapsed.update((isCollapsed) => !isCollapsed);
  }

  private getInitialTheme(): boolean {
    const savedTheme = this.getSavedTheme();

    if (savedTheme === 'dark') {
      return true;
    }

    if (savedTheme === 'light') {
      return false;
    }

    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
  }

  private applyTheme(isDarkMode: boolean): void {
    document.documentElement.classList.toggle('dark', isDarkMode);
    try {
      localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    } catch {
      // Storage can be unavailable in restricted browser contexts or tests.
    }
  }

  private getSavedTheme(): string | null {
    try {
      return localStorage.getItem('theme');
    } catch {
      return null;
    }
  }
}
